<?php

	//The coe wants to log out.XDDD>.... Help him



session_start();
{
	
	session_destroy();
	//Uncomment this line
	header("Location: masterlanding.html");
	
}

?>