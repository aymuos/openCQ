<?php

//This should be present.
header("Content-Type:application/json");
define("key","SherlockNeedsWatson");

define("bank","questionBank/");
define("exam","exam/");
$key = key;
// define("bank","questionBank");

?>