<?php
$_GET['key']=key;
$_GET['stream']="CSE";
$_GET['joining_year']="1";
$_GET['batch_passout_year']="1";