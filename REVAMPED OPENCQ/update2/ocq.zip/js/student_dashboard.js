function func(){
	alert(obj[2]);
}
