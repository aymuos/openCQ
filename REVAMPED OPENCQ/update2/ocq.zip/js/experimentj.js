function hideFunction() {
    var x = document.getElementById("teachernamecard");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  } 

//            ||||||||||
//               //\\
//                |
  //js function for hiding the teacher name div    



  