<?php

//This should be present.
header("Content-Type:application/json");
$key = "hJxBHbjbJBJUbdjkHldcsjbBVD";

?>